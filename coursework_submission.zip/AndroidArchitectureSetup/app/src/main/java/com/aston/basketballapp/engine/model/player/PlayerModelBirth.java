package com.aston.basketballapp.engine.model.player;
public class PlayerModelBirth {
    String date;
    String country;

    public String getDate() {
        return date;
    }

    public String getCountry() {
        return country;
    }
}
