package com.aston.basketballapp.engine.model.player;
public class PlayerModelLeagues {
    PlayerModelStandard standard;

    public PlayerModelStandard getStandard() {
        return standard;
    }

}
