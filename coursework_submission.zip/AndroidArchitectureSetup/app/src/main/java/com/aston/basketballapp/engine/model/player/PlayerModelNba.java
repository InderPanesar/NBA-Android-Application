package com.aston.basketballapp.engine.model.player;
public class PlayerModelNba {
    int start;
    int pro;

    public int getStart() {
        return start;
    }

    public int getPro() {
        return pro;
    }
}
