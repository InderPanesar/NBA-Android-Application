package com.aston.basketballapp.engine.model.player.stats;
public class PlayerStatisticsGameModel {
    int id;
}
