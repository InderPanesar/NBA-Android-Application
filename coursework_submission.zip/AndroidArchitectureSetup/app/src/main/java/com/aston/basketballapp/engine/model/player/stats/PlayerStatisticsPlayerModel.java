package com.aston.basketballapp.engine.model.player.stats;
public class PlayerStatisticsPlayerModel {
    int id;
    String firstname;
    String lastname;
}
