package com.aston.basketballapp.engine.model.player.stats;
public class PlayerStatisticsTeamModel {
    int id;
    String name;
    String nickname;
    String code;
    String logo;
}
