package com.aston.basketballapp.engine.model.schedule.gameStatistics;
public class GameStatisticsTeam {
    int id;
    String name;
    String nickname;
    String code;
    String logo;
}
