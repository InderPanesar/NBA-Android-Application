package com.aston.basketballapp.engine.model.schedule.schedule;
public class ScheduleDateModel {
    String start;
    String end;
    String duration;
}
