package com.aston.basketballapp.engine.model.schedule.schedule;
public class ScheduleModelArena {
    String name;
    String city;
    String state;
    String country;
}
