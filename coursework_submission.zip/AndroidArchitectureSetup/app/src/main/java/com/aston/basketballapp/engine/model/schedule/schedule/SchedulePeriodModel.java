package com.aston.basketballapp.engine.model.schedule.schedule;
public class SchedulePeriodModel {
    int current;
    int total;
    boolean endOfPeriod;
}
