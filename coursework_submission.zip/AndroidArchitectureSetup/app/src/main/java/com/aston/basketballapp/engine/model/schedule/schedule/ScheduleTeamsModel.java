package com.aston.basketballapp.engine.model.schedule.schedule;
public class ScheduleTeamsModel {
    TeamScheduleModel visitors;
    TeamScheduleModel home;
}
