package com.aston.basketballapp.engine.model.schedule.schedule;
public class ScheduleTeamsScoreModel {
    TeamScheduleScore visitors;
    TeamScheduleScore home;

}
