package com.aston.basketballapp.engine.model.schedule.schedule;

public class ScoreModel {
    String points;

    public String getPoints() { return points; }
}
