package com.aston.basketballapp.engine.model.schedule.schedule;
public class TeamScheduleScore {
    int win;
    int loss;
    int points;
}
