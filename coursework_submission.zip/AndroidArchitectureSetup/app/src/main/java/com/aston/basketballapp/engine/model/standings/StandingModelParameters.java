package com.aston.basketballapp.engine.model.standings;
public class StandingModelParameters {
    String league;
    String season;
    String team;
}
