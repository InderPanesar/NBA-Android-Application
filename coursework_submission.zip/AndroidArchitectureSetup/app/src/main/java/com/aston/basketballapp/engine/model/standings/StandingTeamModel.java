package com.aston.basketballapp.engine.model.standings;
public class StandingTeamModel {
    int id;
    String name;
    String nickname;
    String code;
    String logo;

    public int getId() {
        return id;
    }
}
