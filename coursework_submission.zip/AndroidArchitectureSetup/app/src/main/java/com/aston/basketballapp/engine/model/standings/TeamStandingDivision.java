package com.aston.basketballapp.engine.model.standings;
public class TeamStandingDivision {
    String name;
    int rank;
    int win;
    int loss;
    String gamesBehind;
}
