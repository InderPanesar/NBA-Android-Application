package com.aston.basketballapp.engine.model.teams;
public class TeamsStandardModel {
    String conference;
    String division;

    public String getConference() {
        return conference;
    }

    public String getDivision() {
        return division;
    }
}
