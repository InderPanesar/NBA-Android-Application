package com.aston.basketballapp.utils;

//Interface class to stop child fragments being able to open the drawer menu.
public interface DrawerLayoutControl {
    public void setDrawerEnabled(boolean enabled);
}
